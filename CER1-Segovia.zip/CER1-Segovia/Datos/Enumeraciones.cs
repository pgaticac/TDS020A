﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datos
{
   public enum Profesion
    {
        Soldador,
        Ceramista,
        Pintor,
        Carpintero,
        Constructor,
        Ingeniero,
        Arquitecto
    }

    public enum Experiencia
    {
        Junior,
        Maestro,
        Instructor
    }
}
