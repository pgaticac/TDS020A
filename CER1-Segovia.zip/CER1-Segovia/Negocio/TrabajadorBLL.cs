﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Datos;

namespace Negocio
{
    public class TrabajadorBLL
    {
        List<Trabajador> trabajadores;

        public TrabajadorBLL()
        {
            trabajadores = new List<Trabajador>();
        }

        public void Add(Trabajador t)
        {
            //Validaciones de negocio

            //Agregar a la colección
            trabajadores.Add(t);
        }

        public List<Trabajador> getAll()
        {
            return this.trabajadores;
        }
    }
}
