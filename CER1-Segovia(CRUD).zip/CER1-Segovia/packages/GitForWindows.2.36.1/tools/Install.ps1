param($installPath, $toolsPath, $package, $project)

"$toolsPath\post-install.bat"
